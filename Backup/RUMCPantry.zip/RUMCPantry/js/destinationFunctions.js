function ap_ao1Back() {
    window.location.assign("ap1.php");
}

function ap_ao2Back() {
    window.location.assign("ap_ao1.php");
}

function ap_ao3Back() {
    window.location.assign("ap_ao1.php");
}

function ap_ao4Back() {
    window.location.assign("ap_ao1.php");
}

function ap_co1Back() {
    window.location.assign("ap1.php");
}

function ap_co1iBack() {
    window.location.assign("ap_co1.php");
}

function ap_co2Back() {
    window.location.assign("ap_co1.php");
}

function ap_co3Back() {
    window.location.assign("ap_co1.php");
}

function ap_co4Back() {
    window.location.assign("ap_co1.php");
}

function ap_co5Back() {
    window.location.assign("ap_co1.php");
}

function ap_do1Back() {
    window.location.assign("ap1.php");
}

function ap_do2Back() {
    window.location.assign("ap_do1.php");
}

function ap_do3Back() {
    window.location.assign("ap_do1.php");
}

function ap_do4Back() {
    window.location.assign("ap_do1.php");
}

function ap_do5Back() {
    window.location.assign("ap_do1.php");
}

function ap_io1Back() {
    window.location.assign("ap1.php");
}

function ap_io2Back() {
    window.location.assign("ap_io1.php");
}

function ap_io3Back() {
    window.location.assign("ap_io1.php");
}

function ap_io4Back() {
    window.location.assign("ap_io1.php");
}

function ap_io5Back() {
    window.location.assign("ap_io1.php");
}

function ap_oo1Back() {
    window.location.assign("ap_io1.php");
}

function ap_oo2Back() {
    window.location.assign("ap_oo1.php");
}

function ap_oo3Back() {
    window.location.assign("ap1.php");
}

function ap_oo4Back() {
    window.location.assign("ap_oo3.php");
}

function ap_oo5Back() {
    window.location.assign("ap_oo1.php");
}

function ap_ro1Back() {
    window.location.assign("ap1.php");
}

function ap_ro2Back() {
    window.location.assign("ap_ro1.php");
}

function ap_ro2iBack() {
    window.location.assign("ap_ro2.php");
}

function ap_ro3Back() {
    window.location.assign("ro1.php");
}

function ap_ro4Back() {
    window.location.assign("ro1.php");
}

function ap_ro5Back() {
    window.location.assign("ap_ro1.php");
}

function ap1Back() {
    window.location.assign("mainpage.php");
}

function awcBack() {
    window.location.assign("checkIn.php");
}

function capBack() {
    window.location.assign("mainpage.php");
}

function checkInBack() {
    window.location.assign("ap1.php");
}

function ciupBack() {
    window.location.assign("mainpage.php");
}

function cofBack() {
    window.location.assign("cp2.php");
}

function cp1Back() {
    window.location.assign("mainpage.php");
}

function cp2Back() {
    window.location.assign("cp1.php");
}

function loginBack() {
    window.location.assign("mainpage.php");
}

function mainpageBack() {
    window.location.assign("mainpage.php");
}