<!DOCTYPE html>

<html>
	<head>
		<title>Roselle United Methodist Church Food Pantry</title>
		<!--<link href='style.css' rel='stylesheet'>-->
	</head>
	
	<style>
	p {
		color : red;
	}
	</style>

	
	<body>
		<h1>Roselle United Methodist Church</h1>
		<h2>Food Pantry</h2>
		<h3>Log In Page</h3>
		
		<form method = "POST" action="php/login.php">
		  Log In: <input type="text" name="login" value="">
		  <br>
		  Password: <input type="password" name="password" value="" autocomplete="off">
		  <br><br>
		  <?php
			if (isset($_GET['err'])) {
				if ($_GET['err'] == 1) {
					echo "<p>Incorrect login or password</p>";
				}
				else if ($_GET['err'] == 2) {
					echo "<p>Please log in</p>";
				}
			}
		  ?>
		  <input type="submit" value="Submit">
		</form>

		or continue as client
		<form method="get" action="mainpage.php">
        <input type="submit" value="continue">
    	</form>
	
		

	</body>
</html>