<!doctype html>
<html>

<head>
    <script src="js/utilities.js"></script>
    <title>ciup</title>
</head>

<body>
    <button onclick="goBack()">Go Back</button>
    <h1>
        Client info update page
    </h1>
</body>

</html>