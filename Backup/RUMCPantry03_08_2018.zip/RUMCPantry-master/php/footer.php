<?php


echo "
        </div><!-- /body-content -->
      </div><!-- /content -->

    </body>
  </html>
  
  <script type='text/javascript' charset='utf8' src='includes/jquery-3.2.1.min.js'></script>
  <script type='text/javascript' charset='utf8' src='includes/chosen/chosen.jquery.min.js'></script>
  <script type='text/javascript' charset='utf8' src='includes/jquery.dataTables.min.js'></script>
  <script type='text/javascript' src='js/utilities.js'></script>
  ";
?>
