<?php
  // © 2018 Daniel Luxa ALL RIGHTS RESERVED
  $pageRestriction = 99;
  include 'php/checkLogin.php';
  include 'php/header.php';
  include 'php/backButton.php';
?>

  <h3>Reallocation Main</h3>

	<div class="body-content">

  <a href="<?=$basePath?>ap_ro2.php" class="button">View Reallocation Partners</a>
  <a href="<?=$basePath?>ap_ro5.php" class="button">View Reallocation Items</a>
  <a href="<?=$basePath?>ap_ro8.php" class="button">View Reallocations</a>


<?php include 'php/footer.php'; ?>