<!-- © 2018 Daniel Luxa ALL RIGHTS RESERVED -->


      </div>
    </div>

  </body>
</html>

<script type='text/javascript' src='includes/jquery-3.2.1.min.js'></script>
<script type='text/javascript' src='includes/chosen/chosen.jquery.min.js'></script>
<script type='text/javascript' src='includes/jquery.dataTables.min.js'></script>
<script type='text/javascript' src='includes/bootstrap/js/bootstrap.min.js'></script>
<script type='text/javascript' src='js/utilities.js'></script>

<script type="text/javascript">
  function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'en,es,fr,it,pl,zh-CN,uk', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: false}, 'google_translate_element');
  }

</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>